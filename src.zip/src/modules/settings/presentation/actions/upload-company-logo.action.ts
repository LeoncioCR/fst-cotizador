"use server";

import { revalidatePath } from "next/cache";

import { redirect } from "next/navigation";

import { PERMISSIONS, requirePermission } from "@/modules/identity";

import { makeCompanyAssets, makeSettingsRepository } from "@/modules/settings";

import { ApplicationError } from "@/shared/errors/application-error";

const MAX_LOGO_SIZE = 2 * 1024 * 1024;

const ALLOWED_TYPES = ["image/png", "image/jpeg", "image/webp"];

export async function uploadCompanyLogoAction(formData: FormData) {
  /*
   * RN-CONF-003
   * Solo configuracion.editar
   * puede modificar el logo.
   */
  await requirePermission(PERMISSIONS.SETTINGS.EDIT);

  const file = formData.get("logo");

  if (!(file instanceof File)) {
    throw new ApplicationError("Debe seleccionar un archivo.", "INVALID_LOGO");
  }

  if (file.size === 0) {
    throw new ApplicationError(
      "El archivo seleccionado está vacío.",
      "INVALID_LOGO",
    );
  }

  /*
   * Límite real de negocio:
   * 2 MB.
   *
   * Next permite 3 MB en el request
   * únicamente para dejar margen al
   * multipart/form-data.
   */
  if (file.size > MAX_LOGO_SIZE) {
    throw new ApplicationError(
      "El logo no puede superar los 2 MB.",
      "INVALID_LOGO_SIZE",
    );
  }

  if (!ALLOWED_TYPES.includes(file.type)) {
    throw new ApplicationError(
      "El logo debe ser PNG, JPG, JPEG o WEBP.",
      "INVALID_LOGO_TYPE",
    );
  }

  /*
   * Subimos el archivo a Storage.
   *
   * RN-CONF-007:
   * el binario NO se almacena
   * en PostgreSQL.
   */
  const assets = makeCompanyAssets();

  const logoPath = await assets.uploadLogo(file);

  /*
   * PostgreSQL guarda solamente
   * la referencia/ruta.
   */
  const repository = makeSettingsRepository();

  await repository.updateCompanyLogo(logoPath);

  revalidatePath("/configuracion");

  redirect("/configuracion");
}
