import "server-only";

import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  throw new Error("DATABASE_URL no está configurado");
}

const client = postgres(databaseUrl, {
  max: 1,
  prepare: false,
  ssl: "require",
});

export const db = drizzle(client);
